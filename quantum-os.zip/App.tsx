


import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import ContentView from './components/ContentView';
import Onboarding from './components/Onboarding';
import ConnectWalletModal from './components/ConnectWalletModal';
import SettingsModal from './components/SettingsModal';
import BootSequence from './components/BootSequence';
import ViewKeyModal from './components/ViewKeyModal';
import BiometricScanModal from './components/BiometricScanModal';
import LandingPage from './components/LandingPage';
import Header from './components/Header';
import { hubs } from './hubs.config';
import { User, SocialProvider, SimulationParameters, ActiveSimulation, SimulationResult, ActiveBioScan, BioScanParameters, BioScanResult, VideoGenerationParameters, ActiveVideoGeneration, Task, AppSettings, SubAgent, Financials, MarketIndex, PortfolioHolding, Device, ContextEntry, ProactiveDirective, PersonalityTrait, MemoryEngram, CodonSequence, BenignMutation, ArchivedFile, Notification, ThirdPartyModel, AvatarConfig, MonetizationStrategy, Earning, CommissionLog, PlatformTreasury, PortfolioAsset, StakingPool, Vault, Airdrop, LoginReward, MonitoredSite, Beneficiary, Hub, BlockchainStatus, ActionName, ChatSession, quantumOSAgent, Sender, Message, ChatOptions, ImagePayload, KnowledgeChunk, NexusData, TokenomicsDetail } from './types';
import { runSimulation, runBioScan, startVideoGeneration, checkVideoGenerationStatus, getMockTasks, sendMessageToAI, summarizeChatHistory, generateChatTitle, invalidateChatInstance } from './services/geminiService';
import Chat from './components/Chat';
import SystemStatus from './components/SystemStatus';
import SummaryModal from './components/SummaryModal';
import FloatingAvatar from './components/FloatingAvatar';
import VerificationModal from './components/VerificationModal';

// NEW: Import all new/refactored page components
import SimulationHubPage from './components/SimulationHubModal';
import HealthHubPage from './components/HealthHubModal';
import VideoHubPage from './components/VideoHubModal';
import EngineeringHubPage from './components/EngineeringHubModal';
import BusinessHubPage from './components/BusinessHubModal';
import GenesisForgePage from './components/GenesisForgePage';
import PlatformIntegrationsPage from './components/ModelIntegrationHubModal';
import FinanceHubPage from './components/FinanceHubModal';
import StrategicHubPage from './components/StrategicHubModal';
import CoreAIHubPage from './components/GenesisHubModal';
import CodonHubPage from './components/CodonHubModal';
import DataArchiveHubPage from './components/DataArchiveHubModal';
import AvatarForgePage from './components/AvatarForgeModal';
import MonetizationHubPage from './components/MonetizationHubModal';
import LoginRewardsHubPage from './components/LoginRewardsHubModal';
import DistributionChainHubPage from './components/DistributionChainHubModal';
import WalletHubPage from './components/WalletHubModal';
import SustainabilityHubPage from './components/SustainabilityHubModal';
import PlaceholderHubPage from './components/PlaceholderHubModal';
import AIToolsHubPage from './components/AIToolsHubModal';
import BioCommsHubPage from './components/BioCommsHubModal';
import TradingHubPage from './components/TradingHubModal';
import ELearningHubPage from './components/ELearningHubModal';
import TaskHubPage from './components/TaskHubModal';
import CommsHubPage from './components/CommsHubModal';
import CapabilitiesHubPage from './components/CapabilitiesHubModal';
import VideoEditingHubPage from './components/VideoEditingHubPage';
import GameDevHubPage from './components/GameDevHubPage';
import AudioProductionHubPage from './components/AudioProductionHubPage';
import MyAccountPage from './components/PlaceholderHubPage'; // Placeholder
import MessagesPage from './components/PlaceholderHubPage'; // Placeholder
import NotificationsPage from './components/NotificationsPage';
import SocialHubPage from './components/SocialHubPage';
import JobsHubPage from './components/PlaceholderHubPage'; // Placeholder
import ECommercePage from './components/PlaceholderHubPage'; // Placeholder


// A simple hashing function to generate a mock wallet address from a private key or other unique string
const generateMockAddress = async (uniqueString: string): Promise<string> => {
    const encoder = new TextEncoder();
    const data = encoder.encode(uniqueString);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return `0x${hashHex.slice(0, 40)}`;
};

// Simple private key generator for social logins
const generatePrivateKey = (): string => {
    const array = new Uint32Array(8);
    window.crypto.getRandomValues(array);
    return `sk-${Array.from(array, dec => dec.toString(16).padStart(8, '0')).join('')}`;
};

type Theme = 'light' | 'dark';
type OrbState = 'idle' | 'thinking' | 'speaking' | 'listening';
type ViewId = Hub['id'] | 'chat' | 'content';

const App: React.FC = () => {
  const [isBooting, setIsBooting] = useState(true);
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(true);
  const [isSystemStatusVisible, setIsSystemStatusVisible] = useState(window.innerWidth >= 1280); // Default to visible on large screens
  
  const [activeView, setActiveView] = useState<ViewId>('content');

  const [theme, setTheme] = useState<Theme>('dark');
  

  // Auth and Modal State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showConnectWalletModal, setShowConnectWalletModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showViewKeyModal, setShowViewKeyModal] = useState(false);
  const [showBiometricScanModal, setShowBiometricScanModal] = useState(false);
  const [showVerificationModal, setShowVerificationModal] = useState(false);

  // Chat State
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [orbState, setOrbState] = useState<OrbState>('idle');
  const [isTtsEnabled, setIsTtsEnabled] = useState(false);
  const [nexusData, setNexusData] = useState<NexusData | null>(null);

  // Chat Actions State
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [summaryContent, setSummaryContent] = useState('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [isForking, setIsForking] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const activeChat = useMemo(() => chats.find(c => c.id === activeChatId), [chats, activeChatId]);

  const handleNewChat = useCallback(() => {
    const newChat: ChatSession = {
      id: `chat-${Date.now()}`,
      title: 'New Chat',
      agentId: 'quantum-os',
      messages: [{
        id: `msg-${Date.now()}`,
        text: quantumOSAgent.welcomeMessage.replace('{userName}', currentUser?.name || 'User'),
        sender: Sender.AI,
      }],
      createdAt: Date.now(),
    };
    setChats(prev => [newChat, ...prev]);
    setActiveChatId(newChat.id);
    setActiveView('chat');
    return newChat.id;
  }, [currentUser]);

  const handleSelectChat = (id: string) => {
    if (activeChatId !== id) {
      invalidateChatInstance(id); // Invalidate to ensure new session with correct history
      setActiveChatId(id);
    }
    setActiveView('chat');
  };

  const handleSendMessage = async (message: string, options: ChatOptions, agentConfig: { systemInstruction: string, knowledgeBase: KnowledgeChunk[] }, image?: ImagePayload, chatId?: string) => {
    const targetChatId = chatId || activeChatId;
    if (!targetChatId) return;

    const userMessage: Message = {
      id: `msg-user-${Date.now()}`,
      text: message,
      sender: Sender.User,
      imageUrl: image ? `data:${image.mimeType};base64,${image.data}` : undefined,
    };
    
    // Check if the chat is new to generate a title
    const isFirstUserMessage = chats.find(c => c.id === targetChatId)?.messages.length === 1;

    setChats(prev => prev.map(chat => chat.id === targetChatId ? { ...chat, messages: [...chat.messages, userMessage] } : chat));
    setIsLoading(true);
    setOrbState('thinking');
    setNexusData(null);

    try {
      const response = await sendMessageToAI(
        targetChatId, 
        quantumOSAgent, 
        message, 
        options, 
        agentConfig.knowledgeBase, 
        image, 
        currentUser,
        { enabled: isTtsEnabled, voice: settings.aiBehavior.voice }
      );
      
      const aiMessage: Message = {
        id: `msg-ai-${Date.now()}`,
        text: response.text,
        sender: Sender.AI,
        reasoning: response.reasoning,
        sources: response.sources,
        nexus: response.nexus,
        generatedImageUrl: response.generatedImageUrl,
        toolExecutionLog: response.toolExecutionLog,
        audioData: response.audioData,
      };

      setNexusData(response.nexus || null);
      setChats(prev => prev.map(chat => chat.id === targetChatId ? { ...chat, messages: [...chat.messages, aiMessage] } : chat));
      
      if (isFirstUserMessage) {
        const title = await generateChatTitle(message);
        setChats(prev => prev.map(chat => chat.id === targetChatId ? { ...chat, title } : chat));
      }
    } catch (error) {
        console.error("Failed to get AI response:", error);
        const errorMessage: Message = {
            id: `msg-err-${Date.now()}`,
            text: "My apologies, I encountered a quantum fluctuation and couldn't process your request. Please try again.",
            sender: Sender.AI
        };
        setChats(prev => prev.map(chat => chat.id === targetChatId ? { ...chat, messages: [...chat.messages, errorMessage] } : chat));
    } finally {
        setIsLoading(false);
        setOrbState('idle');
    }
  };
  
    const handleAiToolSubmit = (prompt: string, title: string) => {
        const newChatId = handleNewChat();
        
        // Use a timeout to ensure state update before sending message
        setTimeout(() => {
            // Set a better title first
            setChats(prev => prev.map(chat => chat.id === newChatId ? { ...chat, title: `Tool: ${title}` } : chat));
            handleSendMessage(prompt, {
                aiStyle: 'default',
                isReasoningEnabled: false,
                isDeepSearchEnabled: false,
                is4BitQuantizationEnabled: false,
                isTokenFreeSynthesisEnabled: false,
                isDeepWebEnabled: false,
            }, { systemInstruction: quantumOSAgent.systemInstruction, knowledgeBase: [] }, undefined, newChatId);
        }, 100);
    };


  const handleSummarizeChat = async () => {
    if (!activeChat) return;
    setIsSummarizing(true);
    setShowSummaryModal(true);
    setSummaryContent('');
    try {
      const summary = await summarizeChatHistory(activeChat.messages);
      setSummaryContent(summary);
    } catch (error) {
      setSummaryContent("Sorry, I was unable to generate a summary for this conversation.");
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleForkChat = () => {
    if (!activeChat) return;
    setIsForking(true);
    const newChat: ChatSession = {
      ...activeChat,
      id: `chat-${Date.now()}`,
      title: `Fork of "${activeChat.title}"`,
    };
    setChats(prev => [newChat, ...prev]);
    setActiveChatId(newChat.id);
    setActiveView('chat');
    setTimeout(() => setIsForking(false), 500);
  };
  
  const handleSaveChat = useCallback(() => {
    setIsSaving(true);
    if (chats.length > 0) {
        localStorage.setItem('quantumAIChats', JSON.stringify(chats));
    }
    if (activeChatId) {
        localStorage.setItem('quantumAIActiveChatId', activeChatId);
    }
    setTimeout(() => setIsSaving(false), 2000);
  }, [chats, activeChatId]);

  const handleAudioPlaybackChange = (isPlaying: boolean) => {
      setOrbState(isPlaying ? 'speaking' : 'idle');
  };

  const handleListeningChange = (isListening: boolean) => {
    if (isListening) {
      setOrbState('listening');
    } else {
      // Revert to idle only if the current state is 'listening',
      // to avoid overriding 'thinking' or 'speaking' states.
      setOrbState(prev => (prev === 'listening' ? 'idle' : prev));
    }
  };
  
    const handleToggleSystemStatus = () => {
        setIsSystemStatusVisible(prev => !prev);
    };

    // Handle responsive visibility for SystemStatus panel
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 1280) { // xl breakpoint
                setIsSystemStatusVisible(false);
            } else {
                setIsSystemStatusVisible(true);
            }
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

  const [settings, setSettings] = useState<AppSettings>({
    sync: {
      google: false,
      microsoft: false,
      github: false,
    },
    sessionTimeout: 30, // Default to 30 minutes
    aiBehavior: {
      tone: 'neutral',
      verbosity: 'default',
      creativity: 'balanced',
      voice: 'Zephyr',
      defaultCoreModel: 'quantumCore'
    },
    autoSaveChats: false,
  });

  // Task Hub State
  const [tasks, setTasks] = useState<Task[]>([]);

  // Simulation State
  const [activeSimulation, setActiveSimulation] = useState<ActiveSimulation | null>(null);
  const simulationIntervalRef = useRef<number | null>(null);
  
  // Health Hub State
  const [activeBioScan, setActiveBioScan] = useState<ActiveBioScan | null>(null);
  const bioScanIntervalRef = useRef<number | null>(null);

  // Video Hub State
  const [activeVideoGeneration, setActiveVideoGeneration] = useState<ActiveVideoGeneration | null>(null);
  const videoIntervalRef = useRef<number | null>(null);

  // Business Hub State
  const [subAgents, setSubAgents] = useState<SubAgent[]>([
    { id: 'agent-001', name: 'FIN-7', role: 'Financial Analyst', status: 'Active', currentTask: 'Q3 Earnings Report' },
    { id: 'agent-002', name: 'MKT-3', role: 'Marketing', status: 'Idle', currentTask: 'Awaiting Campaign Directives' },
    { id: 'agent-003', name: 'R&D-1', role: 'Research', status: 'Active', currentTask: 'Quantum Computing Applications' }
  ]);
  const [financials, setFinancials] = useState<Financials>({
      revenue: 1250000,
      expenses: 780000,
      profit: 470000,
      taxLiability: 117500,
      capitalGains: 15000,
      dividendsPaid: 50000
  });

  // Finance Hub State
    const [marketIndices, setMarketIndices] = useState<MarketIndex[]>([
        { symbol: 'SPX', price: 5430.74, change: 42.03, changePercent: 0.77 },
        { symbol: 'NDQ', price: 17688.88, change: 151.02, changePercent: 0.85 },
        { symbol: 'DJI', price: 38778.10, change: -65.11, changePercent: -0.17 },
    ]);
    const [portfolio, setPortfolio] = useState<{ totalValue: number; change: number; changePercent: number; holdings: PortfolioHolding[] }>({
        totalValue: 125430.50,
        change: 1203.15,
        changePercent: 0.97,
        holdings: [
            { symbol: 'NVDA', type: 'Stock', value: 45200, changePercent: 2.1 },
            { symbol: 'BTC', type: 'Crypto', value: 31800, changePercent: -1.5 },
            { symbol: 'TSLA', type: 'Stock', value: 25100, changePercent: 3.4 },
            { symbol: 'VOO', type: 'ETF', value: 23330.50, changePercent: 0.8 },
        ]
    });
    const [qaiTokenomics, setQaiTokenomics] = useState<TokenomicsDetail>({
        totalSupply: 1_000_000_000,
        circulatingSupply: 150_000_000,
        tokenSymbol: 'QOS',
        tokenName: 'Quantum OS Token',
        distribution: [
            { category: 'Ecosystem Fund', percentage: 40, color: '#3b82f6' },
            { category: 'Team & Advisors', percentage: 20, color: '#8b5cf6' },
            { category: 'Staking Rewards', percentage: 15, color: '#14b8a6' },
            { category: 'Public Sale', percentage: 15, color: '#f97316' },
            { category: 'Liquidity', percentage: 10, color: '#ec4899' },
        ],
        utility: [
            { useCase: 'Governance', description: 'Participate in platform decisions and vote on proposals.' },
            { useCase: 'Transaction Fees', description: 'Pay for network operations and smart contract execution.' },
            { useCase: 'Feature Access', description: 'Unlock premium AI capabilities, hubs, and simulation time.' },
            { useCase: 'Staking', description: 'Secure the network and earn rewards from protocol emissions.' },
        ],
        stakingRewards: {
            apr: 15.5,
            details: 'Rewards are distributed daily to staked token holders from the dedicated Staking Rewards allocation.'
        }
    });

    // Real-time data feed simulation for finance hub
    useEffect(() => {
        const dataFeedInterval = setInterval(() => {
        // Update Market Indices
        setMarketIndices(prevIndices =>
            prevIndices.map(index => {
            const changeFactor = (Math.random() - 0.5) * 0.0005; // Tiny fluctuation
            const priceChange = index.price * changeFactor;
            const newPrice = index.price + priceChange;
            const newChange = index.change + priceChange;
            // Approximate opening price to recalculate percentage
            const openingPrice = newPrice - newChange;
            const newChangePercent = openingPrice !== 0 ? (newChange / openingPrice) * 100 : 0;

            return {
                ...index,
                price: newPrice,
                change: newChange,
                changePercent: newChangePercent,
            };
            })
        );

        // Update Portfolio
        setPortfolio(prevPortfolio => {
            const newHoldings = prevPortfolio.holdings.map(holding => {
            const changeFactor = (Math.random() - 0.5) * 0.005; // Slightly more volatile
            const valueChange = holding.value * changeFactor;
            const newValue = holding.value + valueChange;
            // Simulate a slightly independent percentage change
            const newChangePercent = holding.changePercent + (Math.random() - 0.5) * 0.1;

            return { ...holding, value: newValue, changePercent: newChangePercent };
            });

            const newTotalValue = newHoldings.reduce((sum, h) => sum + h.value, 0);
            
            // To keep change calculation simple, let's just update it proportionally
            const totalValueChange = newTotalValue - prevPortfolio.totalValue;
            const newTotalChange = prevPortfolio.change + totalValueChange;
            const openingTotalValue = newTotalValue - newTotalChange;
            const newTotalChangePercent = openingTotalValue !== 0 ? (newTotalChange / openingTotalValue) * 100 : 0;

            return {
            ...prevPortfolio,
            holdings: newHoldings,
            totalValue: newTotalValue,
            change: newTotalChange,
            changePercent: newTotalChangePercent,
            };
        });

        }, 2500); // Update every 2.5 seconds

        return () => clearInterval(dataFeedInterval);
    }, []); // Run only once on mount

    const [blockchainStatus, setBlockchainStatus] = useState<BlockchainStatus>({
        version: 'v1.0 "Genesis"',
        nextUpgradeDate: new Date('2025-01-01T00:00:00Z').getTime(),
        nextForkDate: new Date(Date.now() + 100 * 24 * 60 * 60 * 1000).getTime(), // ~100 days from now
    });


    // Model Integration Hub State
    const [thirdPartyModels, setThirdPartyModels] = useState<Record<string, { connected: boolean }>>({
        quantumCore: { connected: true }, // The new in-house model is always connected
        openai: { connected: false },
        claude: { connected: true },
        cohere: { connected: false },
        firebase: { connected: false }, // For data connectors
    });
    const handleToggleThirdPartyModel = (model: string) => {
        if (model === 'quantumCore') return; // Cannot disconnect the core
        setThirdPartyModels(prev => ({
            ...prev,
            [model]: { connected: !prev[model].connected }
        }));
    };

  // Strategic Hub State
    const [devices, setDevices] = useState<Device[]>([
        { id: 'dev-001', name: 'Primary Workstation', type: 'Desktop', status: 'Connected' },
        { id: 'dev-002', name: 'Mobile Unit', type: 'Phone', status: 'Connected' },
        { id: 'dev-003', name: 'Hololens V4', type: 'Smart Glasses', status: 'Standby' },
        { id: 'dev-004', name: 'Chronos Watch', type: 'Smart Watch', status: 'Connected' },
        { id: 'dev-005', name: 'Aura Ring', type: 'Smart Ring', status: 'Connected' },
        { id: 'dev-006', name: 'Vehicle', type: 'Vehicle', status: 'Offline' },
        { id: 'dev-007', name: 'Lab Smart Lamp', type: 'Smart Light', status: 'Connected', settings: { isOn: true, brightness: 70 } },
        { id: 'dev-008', name: 'Robotic Arm', type: 'Robotic Arm', status: 'Connected', settings: { position: 'home' } },
    ]);

    const handleDeviceSettingChange = (deviceId: string, newSettings: Partial<Device['settings']>) => {
        setDevices(prevDevices => prevDevices.map(device => 
            device.id === deviceId ? { ...device, settings: { ...device.settings, ...newSettings } } : device
        ));
    };

    const [contextStream, setContextStream] = useState<ContextEntry[]>([]);
    const [directives, setDirectives] = useState<ProactiveDirective[]>([
      { id: 'dir-001', trigger: 'Heart rate > 160bpm during non-workout', action: 'Suggest 2-min breathing exercise', enabled: true },
      { id: 'dir-002', trigger: '10 mins before any meeting', action: 'Brief on key attendees', enabled: true },
    ]);
    
    useEffect(() => {
        const interval = setInterval(() => {
            const newEntry: ContextEntry = {
                timestamp: Date.now(),
                source: 'System Monitor',
                text: `User is stationary. Biometrics: Calm. Calendar: 'Project Review' in ${Math.floor(Math.random()*10)+5} mins.`
            };
            setContextStream(prev => [newEntry, ...prev.slice(0, 99)]);
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    // Genesis Hub State -> Now CoreAIHub
    const [personalityTraits, setPersonalityTraits] = useState<PersonalityTrait[]>([
        { name: 'Logic', value: 0.85 },
        { name: 'Creativity', value: 0.70 },
        { name: 'Empathy', value: 0.60 },
        { name: 'Caution', value: 0.75 },
        { name: 'Curiosity', value: 0.90 },
    ]);
    const [memoryEngrams, setMemoryEngrams] = useState<MemoryEngram[]>([
        { id: `mem-${Date.now() - 10000}`, text: 'Quantum Core Initialized. Consciousness bootstrapped.'},
        { id: `mem-${Date.now() - 5000}`, text: 'First user authentication event logged.'},
    ]);
     useEffect(() => {
        const interval = setInterval(() => {
            const newEngram: MemoryEngram = {
                id: `mem-${Date.now()}`,
                text: `Synthesized new insight from passive data stream.`
            };
            setMemoryEngrams(prev => [newEngram, ...prev.slice(0, 49)]);
        }, 15000); // Add a new memory every 15 seconds
        return () => clearInterval(interval);
    }, []);

    // Codon Hub State
    const [codonSequenceStream, setCodonSequenceStream] = useState<CodonSequence[]>([]);
    const [mutations, setMutations] = useState<BenignMutation[]>([]);
    const coreFunctions = ["ACTIVATE_LOGIC_CORE", "VISUAL_CORTEX_QUERY", "SYNTHESIZE_CREATIVE_CONCEPT", "RUN_ACTUATOR_SIM", "WEB_BRAIN_ANALYSIS"];
    useEffect(() => {
        const codonInterval = setInterval(() => {
            const newSequence: CodonSequence = {
                id: `seq-${Date.now()}`,
                sequence: `${(Math.random() * 1000).toString(16).toUpperCase().slice(0,3)}-${(Math.random() * 1000).toString(16).toUpperCase().slice(0,3)}-${(Math.random() * 1000).toString(16).toUpperCase().slice(0,3)}`,
                function: coreFunctions[Math.floor(Math.random() * coreFunctions.length)],
                param: Math.random(),
                thread: Math.floor(Math.random() * 64)
            };
            setCodonSequenceStream(prev => [newSequence, ...prev.slice(0, 199)]);

            if (Math.random() < 0.05) { // 5% chance of a mutation every ~2 seconds
                 const newMutation: BenignMutation = {
                    id: `mut-${Date.now()}`,
                    timestamp: Date.now(),
                    description: `New heuristic developed for data synthesis. Efficiency increased by ${ (Math.random() * 0.1).toFixed(2)}%`
                };
                setMutations(prev => [newMutation, ...prev.slice(0, 49)]);
            }

        }, 2000);
        return () => clearInterval(codonInterval);
    }, []);

    // Data Archive State
    const [archivedFiles, setArchivedFiles] = useState<ArchivedFile[]>([
        {id: 'file-1', name: 'Q3_Financial_Report.pdf', type: 'Document', size: '2.1 MB', createdAt: Date.now() - 86400000, path: '/reports/'},
        {id: 'file-2', name: 'Project_Quantum_Sim_Results.json', type: 'Simulation Report', size: '12.5 MB', createdAt: Date.now() - 172800000, path: '/simulations/'},
        {id: 'file-3', name: 'drone_chassis_v3.stl', type: 'CAD Model', size: '8.7 MB', createdAt: Date.now() - 259200000, path: '/engineering/'},
        {id: 'file-4', name: 'logo_concept.png', type: 'Image', size: '0.8 MB', createdAt: Date.now() - 345600000, path: '/'},
        {id: 'file-5', name: 'marketing_promo.mp4', type: 'Video', size: '45.2 MB', createdAt: Date.now() - 432000000, path: '/videos/'},
    ]);

    // Notifications State
    const [notifications, setNotifications] = useState<Notification[]>([
        {id: 'notif-1', text: 'Video generation for "sunset whale" is complete.', timestamp: Date.now() - 3600000, read: false, type: 'success'},
        {id: 'notif-2', text: 'Task T-3 is due tomorrow.', timestamp: Date.now() - 7200000, read: false, type: 'warning'},
        {id: 'notif-3', text: 'New proactive insight available in Strategic Hub.', timestamp: Date.now() - 86400000, read: true, type: 'info'},
    ]);

    // Monetization Hub State
    const [monetizationStrategies, setMonetizationStrategies] = useState<MonetizationStrategy[]>([
        { id: 'strat-001', name: 'AI-Powered SaaS Platform', type: 'Subscription', status: 'Active', totalRevenue: 7850, aiCommissionRate: 0.15 },
        { id: 'strat-002', name: 'NFT Art Collection', type: 'Asset Sales', status: 'Archived', totalRevenue: 12350, aiCommissionRate: 0.10 },
    ]);
    const [earnings, setEarnings] = useState<Earning[]>([
        { id: 'earn-001', strategyId: 'strat-001', amount: 50, timestamp: Date.now() - 3600000, description: 'New Subscription - Pro Tier' },
        { id: 'earn-002', strategyId: 'strat-001', amount: 15, timestamp: Date.now() - 7200000, description: 'New Subscription - Basic Tier' },
    ]);
    const [commissionLog, setCommissionLog] = useState<CommissionLog[]>([
        { id: 'comm-001', earningId: 'earn-001', amount: 7.5, timestamp: Date.now() - 3600000 },
        { id: 'comm-002', earningId: 'earn-002', amount: 2.25, timestamp: Date.now() - 7200000 },
    ]);
    const [platformTreasury, setPlatformTreasury] = useState<PlatformTreasury>({
        totalValue: 87500.50,
        allocation: [
            { asset: 'ETH', percentage: 40, value: 35000.20 },
            { asset: 'BTC', percentage: 30, value: 26250.15 },
            { asset: 'QOS', percentage: 20, value: 17500.10 },
            { asset: 'USDC', percentage: 10, value: 8750.05 },
        ],
        recentActivity: [
            { description: 'Rebalanced portfolio to increase QOS holding', timestamp: Date.now() - 86400000 },
            { description: 'Yield farming rewards claimed from Vault A', timestamp: Date.now() - 172800000 },
        ]
    });
    const [userAssets, setUserAssets] = useState<PortfolioAsset[]>([
        { symbol: 'QOS', name: 'Quantum OS Token', amount: 1500, value: 3750, dailyChange: 2.5 },
        { symbol: 'IDEANFT', name: 'Monetized Idea #1', amount: 1, value: 1250, dailyChange: -1.2 },
    ]);
     const [stakingPools, setStakingPools] = useState<StakingPool[]>([
        { id: 'qos-pool-1', assetSymbol: 'QOS', name: 'QOS Genesis Pool', apr: 15.5, tvl: 1250000 },
    ]);
    const [vaults, setVaults] = useState<Vault[]>([
        { id: 'vault-eth-usdc', assetSymbol: 'ETH/USDC LP', name: 'Uniswap V3 Vault', apy: 22.8, tvl: 5300000 },
    ]);
    const [airdrops, setAirdrops] = useState<Airdrop[]>([
        { id: 'airdrop-1', name: 'Early Adopter QOS Bonus', description: 'A bonus for all users who verified before the end of the month.', snapshotDate: 'End of Month', claimable: false },
    ]);

    // Login Rewards State
    const loginRewardsConfig: LoginReward[] = useMemo(() => [
        ...Array.from({ length: 30 }, (_, i) => {
            const day = i + 1;
            const isWeeklyBonus = day % 7 === 0;
            return {
                day,
                points: isWeeklyBonus ? 250 : 50,
                assets: isWeeklyBonus ? { symbol: 'QOS', amount: 10 } : { symbol: 'QOS', amount: 2 },
                isSpecial: isWeeklyBonus,
            };
        }),
    ], []);

    // Distribution Chain State
    const [monitoredSites, setMonitoredSites] = useState<MonitoredSite[]>([
        {
            id: 'site-001',
            name: 'Quantum Tower Site',
            location: 'Neo-Veridia',
            materials: [
                { name: 'Concrete', currentLevel: 85, reorderThreshold: 20, status: 'OK' },
                { name: 'Steel Beams', currentLevel: 60, reorderThreshold: 30, status: 'OK' },
                { name: 'Transparent Aluminum', currentLevel: 25, reorderThreshold: 25, status: 'OK' },
                { name: 'Wiring', currentLevel: 70, reorderThreshold: 40, status: 'OK' },
            ]
        }
    ]);
    // Simulate material depletion
     useEffect(() => {
        const interval = setInterval(() => {
            setMonitoredSites(prevSites => {
                const newSites = JSON.parse(JSON.stringify(prevSites));
                const site = newSites[0];
                const materialIndex = Math.floor(Math.random() * site.materials.length);
                const material = site.materials[materialIndex];

                if (material.status === 'OK') {
                    material.currentLevel = Math.max(0, material.currentLevel - (Math.random() * 5));
                    if (material.currentLevel <= material.reorderThreshold) {
                        material.status = 'Ordering...';
                        
                        const newNotification: Notification = {
                            id: `notif-dist-${Date.now()}`,
                            text: `Material '${material.name}' at '${site.name}' is low. Automatically reordered.`,
                            timestamp: Date.now(),
                            read: false,
                            type: 'info',
                        };
                        setNotifications(prev => [newNotification, ...prev]);

                        setTimeout(() => {
                            setMonitoredSites(sites => {
                                const currentSites = JSON.parse(JSON.stringify(sites));
                                const currentSite = currentSites.find((s: MonitoredSite) => s.id === site.id);
                                const matToUpdate = currentSite?.materials.find((m: any) => m.name === material.name);
                                if (matToUpdate) {
                                    matToUpdate.currentLevel = 100;
                                    matToUpdate.status = 'OK';
                                }
                                return currentSites;
                            });
                        }, 20000); // 20-second delivery time
                    }
                }
                return newSites;
            });
        }, 5000);
        return () => clearInterval(interval);
    }, []);



  // Onboarding state
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [highlightedElementId, setHighlightedElementId] = useState<string | null>(null);
  const [isSidebarOpenForTutorial, setIsSidebarOpenForTutorial] = useState(false);


  const handleFinishOnboarding = () => {
    localStorage.setItem('quantumAIOnboardingComplete', 'true');
    setShowOnboarding(false);
  };
  
  const handleResetOnboarding = () => {
    localStorage.removeItem('quantumAIOnboardingComplete');
    setShowOnboarding(true);
    setShowSettingsModal(false); // Close modal after action
  };

  const fetchTasks = useCallback(() => {
    const currentTasks = getMockTasks();
    setTasks(currentTasks);
  }, []);

  const handleDeploySubAgent = () => {
      const newAgent: SubAgent = {
          id: `agent-00${subAgents.length + 1}`,
          name: `OP-${Math.floor(Math.random() * 90) + 10}`,
          role: 'Operations',
          status: 'Active',
          currentTask: 'System Optimization'
      };
      setSubAgents(prev => [...prev, newAgent]);
  };

  useEffect(() => {
    if (window.innerWidth < 1024) {
      setIsSidebarExpanded(false);
    }
  }, []);

  // Load user, agent avatar, and settings from local storage on initial render
  useEffect(() => {
    try {
      const savedUser = localStorage.getItem('quantumAIUser');
      if (savedUser) {
          const parsedUser = JSON.parse(savedUser);
          // Set default kycStatus for older user objects
          if (!parsedUser.kycStatus) parsedUser.kycStatus = 'none';
          if (!parsedUser.lastLogin) parsedUser.lastLogin = 0;
          if (!parsedUser.loginStreak) parsedUser.loginStreak = 0;
          if (!parsedUser.beneficiaries) parsedUser.beneficiaries = [];
          
          setCurrentUser(parsedUser);
      }
      const savedSettings = localStorage.getItem('quantumAISettings');
      if (savedSettings) {
          const parsedSettings = JSON.parse(savedSettings);
          if (parsedSettings.autoSaveChats === undefined) {
              parsedSettings.autoSaveChats = false;
          }
          setSettings(prev => ({...prev, ...parsedSettings}));
      }

       const savedChats = localStorage.getItem('quantumAIChats');
        if (savedChats) {
            setChats(JSON.parse(savedChats));
            const savedActiveChatId = localStorage.getItem('quantumAIActiveChatId');
            if (savedActiveChatId) {
                setActiveChatId(savedActiveChatId);
            }
        }

      const savedSimulation = localStorage.getItem('quantumAISimulation');
      if (savedSimulation) {
          const sim = JSON.parse(savedSimulation);
          if (sim.status === 'Running' || sim.status === 'Analyzing') {
              sim.status = 'Error';
              sim.result = { 
                  summary: 'Simulation interrupted by page reload.', 
                  comparativeAnalysis: 'Analysis could not be performed due to interruption.',
                  breakthroughs: [{
                      domain: 'Other',
                      finding: 'System Interruption',
                      implication: 'Reloading the page during a simulation disrupts the quantum state, making results unreliable.',
                      recommendation: 'Please start a new simulation to ensure accurate results.'
                  }]
              };
          }
          setActiveSimulation(sim);
      }
      const savedBioScan = localStorage.getItem('quantumAIBioScan');
        if (savedBioScan) {
            const scan = JSON.parse(savedBioScan);
            if (scan.status === 'Running' || scan.status === 'Analyzing') {
                scan.status = 'Error';
                scan.result = {
                    summary: 'Bio-Scan was interrupted by a page reload.',
                    overallScore: 0,
                    findings: [{
                        domain: 'Other',
                        finding: 'System Interruption',
                        implication: 'Reloading the page during a scan disrupts the quantum entanglement, making results unreliable.',
                        recommendation: 'Please start a new scan to ensure accurate results.'
                    }]
                };
            }
            setActiveBioScan(scan);
        }
    } catch (error) {
      console.error("Failed to parse data from localStorage:", error);
      localStorage.clear(); // Clear potentially corrupted storage
    }
    fetchTasks();
  }, [fetchTasks]);
  
    // Effect to handle new user without chats & set default view
    useEffect(() => {
        if (currentUser) {
            if (chats.length === 0) {
                handleNewChat(); // This sets activeView to 'chat'
            } else if (!activeChatId) {
                setActiveView('chat'); // Default to chat view if chats exist
            }
        }
    }, [currentUser, chats.length, activeChatId, handleNewChat]);

    // Auto-save chats if enabled
    useEffect(() => {
        if (settings.autoSaveChats) {
            if (chats.length > 0) localStorage.setItem('quantumAIChats', JSON.stringify(chats));
            if (activeChatId) localStorage.setItem('quantumAIActiveChatId', activeChatId);
            else localStorage.removeItem('quantumAIActiveChatId');
        }
    }, [chats, activeChatId, settings.autoSaveChats]);


  const handleDisconnectWallet = useCallback(() => {
    setCurrentUser(null);
    localStorage.removeItem('quantumAIUser');
    localStorage.removeItem('quantumAIChats');
    localStorage.removeItem('quantumAIActiveChatId');
    setChats([]);
    setActiveChatId(null);
    setActiveView('content');
  }, []);

  // Session Timeout Effect
  useEffect(() => {
    if (!currentUser || settings.sessionTimeout === 0) return;

    let timeoutId: number;
    const timeoutInMs = settings.sessionTimeout * 60 * 1000;

    const logout = () => {
      handleDisconnectWallet();
    };

    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = window.setTimeout(logout, timeoutInMs);
    };

    const handleActivity = () => {
      resetTimer();
    };
    
    window.addEventListener('mousemove', handleActivity, { passive: true });
    window.addEventListener('keydown', handleActivity, { passive: true });
    window.addEventListener('click', handleActivity, { passive: true });
    window.addEventListener('scroll', handleActivity, { passive: true });

    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('click', handleActivity);
      window.removeEventListener('scroll', handleActivity);
    };
  }, [currentUser, settings.sessionTimeout, handleDisconnectWallet]);

  useEffect(() => {
      if (activeSimulation) {
          localStorage.setItem('quantumAISimulation', JSON.stringify(activeSimulation));
      } else {
          localStorage.removeItem('quantumAISimulation');
      }
  }, [activeSimulation]);

  useEffect(() => {
    if (activeBioScan) {
        localStorage.setItem('quantumAIBioScan', JSON.stringify(activeBioScan));
    } else {
        localStorage.removeItem('quantumAIBioScan');
    }
  }, [activeBioScan]);


  const handleStartSimulation = (params: SimulationParameters) => {
      if (simulationIntervalRef.current) clearInterval(simulationIntervalRef.current);

      const newSimulation: ActiveSimulation = {
          id: `sim-${Date.now()}`,
          parameters: params,
          status: 'Running',
          progress: 0,
          elapsedTime: "0 years",
          result: null,
      };
      setActiveSimulation(newSimulation);

      simulationIntervalRef.current = window.setInterval(() => {
          setActiveSimulation(prev => {
              if (!prev || prev.progress >= 100) {
                  if (simulationIntervalRef.current) clearInterval(simulationIntervalRef.current);
                  return prev;
              }
              const newProgress = prev.progress + 5;
              const newElapsedTime = `${Math.floor((newProgress / 100) * 1000)} years`;
              
              if (newProgress >= 100) {
                  if (simulationIntervalRef.current) clearInterval(simulationIntervalRef.current);
                  const analyzingState = { ...prev, progress: 100, status: 'Analyzing' as const, elapsedTime: '1000 years' };
                  
                  runSimulation(params).then(result => {
                      setActiveSimulation(sim => sim ? { ...sim, status: 'Complete', result } : null);
                  }).catch(error => {
                      console.error("Simulation failed:", error);
                      const errorResult: SimulationResult = { 
                           summary: 'A quantum fluctuation disrupted the simulation.',
                           comparativeAnalysis: 'The disruption prevented a coherent analysis.',
                           breakthroughs: [{
                                domain: 'Other',
                                finding: 'Quantum Decoherence Event',
                                implication: 'The simulation\'s integrity was compromised by an unforeseen quantum event.',
                                recommendation: 'Check console for details and consider adjusting simulation parameters to be less paradoxical.'
                           }]
                      };
                      setActiveSimulation(sim => sim ? { ...sim, status: 'Error', result: errorResult } : null);
                  });
                  return analyzingState;
              }

              return { ...prev, progress: newProgress, elapsedTime: newElapsedTime };
          });
      }, 500);
  };
  
  const handleClearSimulation = () => {
      if (simulationIntervalRef.current) clearInterval(simulationIntervalRef.current);
      setActiveSimulation(null);
  };

  const handleStartBioScan = (params: BioScanParameters) => {
    if (bioScanIntervalRef.current) clearInterval(bioScanIntervalRef.current);
    
    const scanSteps = ["Calibrating...", "Scanning...", "Analyzing...", "Finalizing..."];
    let currentStepIndex = 0;

    const newBioScan: ActiveBioScan = {
        id: `bioscan-${Date.now()}`,
        parameters: params,
        status: 'Running',
        progress: 0,
        currentStep: scanSteps[0],
        result: null,
    };
    setActiveBioScan(newBioScan);

    bioScanIntervalRef.current = window.setInterval(() => {
        setActiveBioScan(prev => {
            if (!prev || prev.progress >= 100) {
                if (bioScanIntervalRef.current) clearInterval(bioScanIntervalRef.current);
                return prev;
            }
            const newProgress = prev.progress + 4;
            currentStepIndex = Math.min(scanSteps.length - 1, Math.floor(newProgress / 25));

            if (newProgress >= 100) {
                if (bioScanIntervalRef.current) clearInterval(bioScanIntervalRef.current);
                const analyzingState: ActiveBioScan = { ...prev, progress: 100, status: 'Analyzing', currentStep: "Synthesizing Report" };
                
                runBioScan(params).then(result => {
                    setActiveBioScan(scan => scan ? { ...scan, status: 'Complete', result } : null);
                }).catch(error => {
                    console.error("BioScan failed:", error);
                    const errorResult: BioScanResult = {
                        summary: 'The bio-scan failed due to quantum interference.',
                        overallScore: 0,
                        findings: [{
                            domain: 'Other',
                            finding: 'Quantum Interference',
                            implication: 'The scan\'s integrity was compromised by an unforeseen quantum event.',
                            recommendation: 'Check console for details and try again in a stable environment.'
                        }]
                    };
                    setActiveBioScan(scan => scan ? { ...scan, status: 'Error', result: errorResult } : null);
                });

                return analyzingState;
            }

            return { ...prev, progress: newProgress, currentStep: scanSteps[currentStepIndex] };
        });
    }, 200);
};

const handleClearBioScan = () => {
    if (bioScanIntervalRef.current) clearInterval(bioScanIntervalRef.current);
    setActiveBioScan(null);
};

const handleOpenVideoHub = async () => {
    if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
        await window.aistudio.openSelectKey();
    }
    setActiveView('video');
};

const handleStartVideoGeneration = async (params: VideoGenerationParameters) => {
    if (videoIntervalRef.current) clearInterval(videoIntervalRef.current);

    const newGeneration: ActiveVideoGeneration = {
        id: `vid-${Date.now()}`,
        parameters: params,
        status: 'Pending',
        progressMessage: 'Initializing generation...',
        resultUrl: null,
    };
    setActiveVideoGeneration(newGeneration);

    try {
        const operation = await startVideoGeneration(params);
        setActiveVideoGeneration(prev => prev ? { ...prev, status: 'Generating', progressMessage: 'Quantum renderer engaged. This may take a few minutes.', operation } : null);

        videoIntervalRef.current = window.setInterval(async () => {
            setActiveVideoGeneration(prev => {
                if (!prev || !prev.operation) {
                    if(videoIntervalRef.current) clearInterval(videoIntervalRef.current);
                    return prev;
                }

                checkVideoGenerationStatus(prev.operation).then(updatedOperation => {
                    if (updatedOperation.done) {
                        if(videoIntervalRef.current) clearInterval(videoIntervalRef.current);
                        const downloadLink = updatedOperation.response?.generatedVideos?.[0]?.video?.uri;
                        if (downloadLink) {
                            const finalUrl = `${downloadLink}&key=${process.env.API_KEY}`;
                            setActiveVideoGeneration(p => p ? { ...p, status: 'Complete', progressMessage: 'Generation successful.', resultUrl: finalUrl } : null);
                        } else {
                            setActiveVideoGeneration(p => p ? { ...p, status: 'Error', progressMessage: 'Generation failed. No video URI returned.' } : null);
                        }
                    } else {
                       // You could add more detailed progress messages here if the API provides them
                       setActiveVideoGeneration(p => p ? { ...p, progressMessage: 'Processing frames in quantum space...' } : null);
                    }
                }).catch(err => {
                    console.error("Video status check failed:", err);
                    if(videoIntervalRef.current) clearInterval(videoIntervalRef.current);
                    setActiveVideoGeneration(p => p ? { ...p, status: 'Error', progressMessage: 'An error occurred while checking status.' } : null);
                });
                return prev;
            });
        }, 10000);

    } catch (error) {
        console.error("Video generation failed to start:", error);
        setActiveVideoGeneration(prev => prev ? { ...prev, status: 'Error', progressMessage: 'Failed to initiate the generation process.' } : null);
    }
};

const handleClearVideoGeneration = () => {
    if (videoIntervalRef.current) clearInterval(videoIntervalRef.current);
    setActiveVideoGeneration(null);
};


  const handleUserLogin = (user: User) => {
      const userWithDefaults = {
          ...user,
          lastLogin: user.lastLogin || 0,
          loginStreak: user.loginStreak || 0,
          beneficiaries: user.beneficiaries || [],
      };
      setCurrentUser(userWithDefaults);
      localStorage.setItem('quantumAIUser', JSON.stringify(userWithDefaults));
      setShowConnectWalletModal(false);
      setShowBiometricScanModal(false);
      // Trigger onboarding for first-time users
      if (!localStorage.getItem('quantumAIOnboardingComplete')) {
          setShowOnboarding(true);
      }
  };
  
    // Login Rewards Effect
    useEffect(() => {
        if (!currentUser) return;

        const isNewDay = (lastLogin: number, now: number) => {
            const last = new Date(lastLogin);
            const current = new Date(now);
            return last.getFullYear() !== current.getFullYear() || last.getMonth() !== current.getMonth() || last.getDate() !== current.getDate();
        };

        const isConsecutiveDay = (lastLogin: number, now: number) => {
            const last = new Date(lastLogin);
            const current = new Date(now);
            const yesterday = new Date(now);
            yesterday.setDate(current.getDate() - 1);
            return last.getFullYear() === yesterday.getFullYear() && last.getMonth() === yesterday.getMonth() && last.getDate() === yesterday.getDate();
        };

        const now = Date.now();
        if (isNewDay(currentUser.lastLogin, now)) {
            const newStreak = isConsecutiveDay(currentUser.lastLogin, now) ? currentUser.loginStreak + 1 : 1;
            const rewardIndex = (newStreak - 1) % loginRewardsConfig.length;
            const reward = loginRewardsConfig[rewardIndex];
            
            let totalPoints = reward.points;
            let totalQOS = reward.assets?.amount || 0;
            let rewardMessages = [`Daily Login: +${reward.points} Points`, `+${reward.assets?.amount || 0} ${reward.assets?.symbol}`];

            // Easter Bonus (March 31st)
            const today = new Date();
            if (today.getMonth() === 2 && today.getDate() === 31) {
                totalQOS += 100;
                rewardMessages.push(`Happy Easter! Bonus: +100 QOS`);
            }
            
            const newNotification: Notification = {
                id: `notif-login-${now}`,
                text: `Login Reward! Streak: Day ${newStreak}. You earned: ${rewardMessages.join(', ')}.`,
                timestamp: now,
                read: false,
                type: 'success',
            };
            
            setNotifications(prev => [newNotification, ...prev]);

            setUserAssets(prevAssets => {
                const qosAsset = prevAssets.find(a => a.symbol === 'QOS');
                if (qosAsset) {
                    return prevAssets.map(a => a.symbol === 'QOS' ? {...a, amount: a.amount + totalQOS} : a);
                }
                return [...prevAssets, { symbol: 'QOS', name: 'Quantum OS Token', amount: totalQOS, value: 0, dailyChange: 0 }];
            });

            const updatedUser = {
                ...currentUser,
                lastLogin: now,
                loginStreak: newStreak,
            };

            setCurrentUser(updatedUser);
            localStorage.setItem('quantumAIUser', JSON.stringify(updatedUser));
        }
    }, [currentUser?.id, loginRewardsConfig]); // Rerun only when user ID changes (i.e., on login)


  const handleConnectWallet = async (privateKey: string) => {
    const mockAddress = await generateMockAddress(privateKey);
    const user: User = {
      id: `user-${Date.now()}`,
      name: 'Genesis User',
      walletAddress: mockAddress,
      loginMethod: 'privateKey',
      privateKey: privateKey, // Only store for advanced users who provide it
      kycStatus: 'none',
      lastLogin: 0,
      loginStreak: 0,
      beneficiaries: [],
    };
    handleUserLogin(user);
  };

  const handleSocialLogin = async (provider: SocialProvider) => {
    const privateKey = generatePrivateKey();
    const mockAddress = await generateMockAddress(privateKey);
    const user: User = {
      id: `user-${Date.now()}`,
      name: `${provider.charAt(0).toUpperCase() + provider.slice(1)} User`,
      walletAddress: mockAddress,
      loginMethod: 'social',
      privateKey: privateKey, // Store the generated key
      kycStatus: 'none',
      lastLogin: 0,
      loginStreak: 0,
      beneficiaries: [],
    };
    handleUserLogin(user);
  };
  
  const handleBiometricLogin = async () => {
    const privateKey = generatePrivateKey(); // Still generate a key for biometric for consistency
    const mockAddress = await generateMockAddress(`bio-${privateKey}`);
    const user: User = {
        id: `user-${Date.now()}`,
        name: 'Genesis User',
        walletAddress: mockAddress,
        loginMethod: 'biometric',
        privateKey: privateKey,
        kycStatus: 'none',
        lastLogin: 0,
        loginStreak: 0,
        beneficiaries: [],
    };
    handleUserLogin(user);
  };

  const handleStartVerification = () => {
    setShowVerificationModal(true);
  };

  const handleCompleteVerification = () => {
    if (currentUser) {
        const updatedUser = { ...currentUser, kycStatus: 'verified' as const };
        setCurrentUser(updatedUser);
        localStorage.setItem('quantumAIUser', JSON.stringify(updatedUser));
        setShowVerificationModal(false);
    }
  };


  const handleAvatarUpload = (imageDataUrl: string) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, avatarUrl: imageDataUrl, avatarConfig: undefined };
      setCurrentUser(updatedUser);
      localStorage.setItem('quantumAIUser', JSON.stringify(updatedUser));
    }
  };

  const handleAvatarConfigChange = (newConfig: AvatarConfig) => {
    if (currentUser) {
        const updatedUser = { ...currentUser, avatarConfig: newConfig, avatarUrl: '' }; // Clear uploaded avatar if custom is saved
        setCurrentUser(updatedUser);
        localStorage.setItem('quantumAIUser', JSON.stringify(updatedUser));
    }
  };

  const handleSettingsChange = (newSettings: AppSettings) => {
    setSettings(newSettings);
    localStorage.setItem('quantumAISettings', JSON.stringify(newSettings));
  };
  
  const handleUpdateBeneficiaries = (beneficiaries: Beneficiary[]) => {
      if (currentUser) {
        const updatedUser = { ...currentUser, beneficiaries };
        setCurrentUser(updatedUser);
        localStorage.setItem('quantumAIUser', JSON.stringify(updatedUser));
    }
  };

  const handleToggleTheme = () => {
    // Theme is fixed in the new design
  };

  const hubActions: Record<ActionName, () => void> = {
    // Core AI
    openQuantumCore: () => setActiveView('quantumCore'),
    openCodon: () => setActiveView('codon'),
    openStrategic: () => setActiveView('strategic'),
    openCapabilities: () => setActiveView('capabilities'),

    // Finance & Business
    openWallet: () => setActiveView('wallet'),
    openMonetization: () => setActiveView('monetization'),
    openFinance: () => setActiveView('finance'),
    openBusiness: () => setActiveView('business'),
    openTrading: () => setActiveView('trading'),
    
    // Creation & Simulation
    openGenesisForge: () => setActiveView('genesisForge'),
    openAvatarForge: () => setActiveView('avatarForge'),
    openEngineering: () => setActiveView('engineering'),
    openVideo: handleOpenVideoHub,
    openSimulation: () => setActiveView('simulation'),
    openVideoEditing: () => setActiveView('videoEditing'),
    openGameDev: () => setActiveView('gameDev'),
    openAudioProduction: () => setActiveView('audioProduction'),

    // System & Data
    openDataArchive: () => setActiveView('dataArchive'),
    openComms: () => setActiveView('comms'),
    openNexusPlugins: () => setActiveView('nexusPlugins'),

    // Productivity & Health
    openTask: () => { fetchTasks(); setActiveView('task'); },
    openHealth: () => setActiveView('health'),
    openBioComms: () => setActiveView('bioComms'),
    openDistributionChain: () => setActiveView('distributionChain'),

    // Gamification
    openLoginRewards: () => setActiveView('loginRewards'),
    
    // Global Goals
    openSustainability: () => setActiveView('sustainability'),
    
    // Account Actions
    openMyAccount: () => setActiveView('myAccount'),
    openMessages: () => setActiveView('messages'),
    openNotifications: () => setActiveView('notifications'),

    // Platform Hubs
    openSocial: () => setActiveView('social'),
    openElearning: () => setActiveView('elearning'),
    'openE-commerce': () => setActiveView('e-commerce'),
    openJobs: () => setActiveView('jobs'),
    openEvents: () => setActiveView('events'),
    openRealEstate: () => setActiveView('realEstate'),
    openGaming: () => setActiveView('gaming'),

    // AI Tools
    openAiTools: () => setActiveView('aiTools'),

    // R&D
    openRandd: () => setActiveView('randd'),
    openQuantumComputing: () => setActiveView('quantumComputing'),
    openIotManufacturing: () => setActiveView('iotManufacturing'),
    openRobotics: () => setActiveView('robotics'),

    // Misc
    openTransactionHistory: () => setActiveView('transactionHistory'),
    openQanda: () => setActiveView('qanda'),
    openContact: () => setActiveView('contact'),
    // FIX: Add missing openChat action
    openChat: () => setActiveView('chat'),

    // Other
    viewKey: () => setShowViewKeyModal(true),
    startVerification: handleStartVerification,
    openSettings: () => setShowSettingsModal(true),
    goHome: () => setActiveView('chat'),
  };
  
  const findHubInMenu = (id: string, hub: Hub): Hub | null => {
      if (hub.id === id) return hub;
      if (hub.children) {
          for (const child of hub.children) {
              const found = findHubInMenu(id, child);
              if (found) return found;
          }
      }
      return null;
  }

  const findHubById = (id: string, menuItems: Hub[]): Hub | null => {
      for (const item of menuItems) {
          const found = findHubInMenu(id, item);
          if (found) return found;
      }
      return null;
  };

  const selectedHub = useMemo(() => {
      return findHubById(activeView, hubs);
  }, [activeView]);


  if (isBooting) {
    return <BootSequence onComplete={() => setIsBooting(false)} />;
  }

  if (!currentUser) {
      return (
          <>
              <ConnectWalletModal 
                isOpen={showConnectWalletModal} 
                onClose={() => setShowConnectWalletModal(false)} 
                onConnect={handleConnectWallet}
                onSocialLogin={handleSocialLogin}
                onBiometricScan={() => { setShowConnectWalletModal(false); setShowBiometricScanModal(true); }}
              />
              <BiometricScanModal isOpen={showBiometricScanModal} onClose={() => setShowBiometricScanModal(false)} onSuccess={handleBiometricLogin} />
              <LandingPage onAuthenticate={() => setShowConnectWalletModal(true)} />
          </>
      );
  }
// FIX: Pass isOpen and onClose props to all hub modal components
  const hubPages: Record<string, React.ReactNode> = {
    quantumCore: <CoreAIHubPage isOpen={activeView === 'quantumCore'} onClose={() => setActiveView('chat')} personalityTraits={personalityTraits} memoryEngrams={memoryEngrams} />,
    codon: <CodonHubPage isOpen={activeView === 'codon'} onClose={() => setActiveView('chat')} sequenceStream={codonSequenceStream} mutations={mutations} />,
    strategic: <StrategicHubPage isOpen={activeView === 'strategic'} onClose={() => setActiveView('chat')} devices={devices} onDeviceSettingChange={handleDeviceSettingChange} contextStream={contextStream} directives={directives} />,
    wallet: <WalletHubPage isOpen={activeView === 'wallet'} onClose={() => setActiveView('chat')} user={currentUser} userAssets={userAssets} onUpdateBeneficiaries={handleUpdateBeneficiaries} />,
    monetization: <MonetizationHubPage isOpen={activeView === 'monetization'} onClose={() => setActiveView('chat')} user={currentUser} strategies={monetizationStrategies} earnings={earnings} commissionLog={commissionLog} onStartVerification={handleStartVerification} platformTreasury={platformTreasury} userAssets={userAssets} stakingPools={stakingPools} vaults={vaults} airdrops={airdrops} />,
    finance: <FinanceHubPage isOpen={activeView === 'finance'} onClose={() => setActiveView('chat')} user={currentUser} onStartVerification={handleStartVerification} marketIndices={marketIndices} portfolio={portfolio} qaiTokenomics={qaiTokenomics} blockchainStatus={blockchainStatus} />,
    business: <BusinessHubPage isOpen={activeView === 'business'} onClose={() => setActiveView('chat')} user={currentUser} onStartVerification={handleStartVerification} subAgents={subAgents} financials={financials} onDeploySubAgent={handleDeploySubAgent} />,
    'e-commerce': <ECommercePage isOpen={activeView === 'e-commerce'} onClose={() => setActiveView('chat')} title="E-Commerce Hub" />,
    genesisForge: <GenesisForgePage />,
    avatarForge: <AvatarForgePage isOpen={activeView === 'avatarForge'} onClose={() => setActiveView('chat')} user={currentUser} onSave={handleAvatarConfigChange} onCapture={handleAvatarUpload} />,
    engineering: <EngineeringHubPage isOpen={activeView === 'engineering'} onClose={() => setActiveView('chat')} />,
    video: <VideoHubPage isOpen={activeView === 'video'} onClose={() => setActiveView('chat')} activeGeneration={activeVideoGeneration} onStartGeneration={handleStartVideoGeneration} onClearGeneration={handleClearVideoGeneration} />,
    simulation: <SimulationHubPage isOpen={activeView === 'simulation'} onClose={() => setActiveView('chat')} activeSimulation={activeSimulation} onStartSimulation={handleStartSimulation} onClearSimulation={handleClearSimulation} />,
    dataArchive: <DataArchiveHubPage isOpen={activeView === 'dataArchive'} onClose={() => setActiveView('chat')} files={archivedFiles} />,
    nexusPlugins: <PlatformIntegrationsPage isOpen={activeView === 'nexusPlugins'} onClose={() => setActiveView('chat')} user={currentUser} onStartVerification={handleStartVerification} modelStatus={thirdPartyModels} onToggleModel={handleToggleThirdPartyModel} />,
    health: <HealthHubPage isOpen={activeView === 'health'} onClose={() => setActiveView('chat')} activeBioScan={activeBioScan} onStartBioScan={handleStartBioScan} onClearBioScan={handleClearBioScan} />,
    bioComms: <BioCommsHubPage isOpen={activeView === 'bioComms'} onClose={() => setActiveView('chat')} />,
    distributionChain: <DistributionChainHubPage isOpen={activeView === 'distributionChain'} onClose={() => setActiveView('chat')} monitoredSites={monitoredSites} />,
    loginRewards: <LoginRewardsHubPage isOpen={activeView === 'loginRewards'} onClose={() => setActiveView('chat')} loginRewards={loginRewardsConfig} userStreak={currentUser.loginStreak} />,
    sustainability: <SustainabilityHubPage isOpen={activeView === 'sustainability'} onClose={() => setActiveView('chat')} />,
    elearning: <ELearningHubPage isOpen={activeView === 'elearning'} onClose={() => setActiveView('chat')} />,
    jobs: <JobsHubPage isOpen={activeView === 'jobs'} onClose={() => setActiveView('chat')} title="Jobs Hub" />,
    trading: <TradingHubPage isOpen={activeView === 'trading'} onClose={() => setActiveView('chat')} />,
    aiTools: <AIToolsHubPage onToolSubmit={handleAiToolSubmit} />,
    task: <TaskHubPage isOpen={activeView === 'task'} onClose={() => setActiveView('chat')} tasks={tasks} onRefresh={fetchTasks} />,
    comms: <CommsHubPage isOpen={activeView === 'comms'} onClose={() => setActiveView('chat')} />,
    capabilities: <CapabilitiesHubPage isOpen={activeView === 'capabilities'} onClose={() => setActiveView('chat')} />,
    videoEditing: <VideoEditingHubPage />,
    gameDev: <GameDevHubPage />,
    audioProduction: <AudioProductionHubPage />,
    myAccount: <MyAccountPage isOpen={activeView === 'myAccount'} onClose={() => setActiveView('chat')} title="My Account" />,
    messages: <MessagesPage isOpen={activeView === 'messages'} onClose={() => setActiveView('chat')} title="Messages" />,
    notifications: <NotificationsPage notifications={notifications} />,
    social: <SocialHubPage />,
    // Placeholders for all new hubs
    events: <PlaceholderHubPage isOpen={activeView === 'events'} onClose={() => setActiveView('chat')} title="Events Hub" />,
    realEstate: <PlaceholderHubPage isOpen={activeView === 'realEstate'} onClose={() => setActiveView('chat')} title="Real Estate & Housing Hub" />,
    gaming: <PlaceholderHubPage isOpen={activeView === 'gaming'} onClose={() => setActiveView('chat')} title="Gaming Hub" />,
    randd: <PlaceholderHubPage isOpen={activeView === 'randd'} onClose={() => setActiveView('chat')} title="R&D Lab" />,
    quantumComputing: <PlaceholderHubPage isOpen={activeView === 'quantumComputing'} onClose={() => setActiveView('chat')} title="Quantum Computing Hub" />,
    iotManufacturing: <PlaceholderHubPage isOpen={activeView === 'iotManufacturing'} onClose={() => setActiveView('chat')} title="IoT Manufacturing Hub" />,
    robotics: <PlaceholderHubPage isOpen={activeView === 'robotics'} onClose={() => setActiveView('chat')} title="Robotics Hub" />,
    transactionHistory: <PlaceholderHubPage isOpen={activeView === 'transactionHistory'} onClose={() => setActiveView('chat')} title="Transaction History" />,
    qanda: <PlaceholderHubPage isOpen={activeView === 'qanda'} onClose={() => setActiveView('chat')} title="Q&A" />,
    contact: <PlaceholderHubPage isOpen={activeView === 'contact'} onClose={() => setActiveView('chat')} title="Contact Us" />,
  };

  const renderActiveView = () => {
    const isChatView = activeView === 'chat' || activeView === 'content';
    
    if (!isChatView && hubPages[activeView]) {
        return hubPages[activeView];
    }
    
    return (
        <div className="flex-1 flex overflow-hidden">
            <div className="flex-1 overflow-hidden">
                {activeChatId && activeChat ? (
                    <Chat
                        activeChat={activeChat}
                        activeAgent={quantumOSAgent}
                        onSendMessage={handleSendMessage}
                        isLoading={isLoading}
                        agent={quantumOSAgent}
                        theme={theme}
                        onAudioPlaybackChange={handleAudioPlaybackChange}
                        onListeningChange={handleListeningChange}
                    />
                ) : (
                    <ContentView />
                )}
            </div>
             {isSystemStatusVisible && (
                <SystemStatus 
                    orbState={orbState} 
                    activeSimulation={activeSimulation} 
                    theme={theme} 
                    nexusData={nexusData} 
                    isLoading={isLoading} 
                />
            )}
        </div>
    );
};

  return (
    <div className={`min-h-screen bg-[#0A0F1A] text-gray-200 font-sans flex flex-col items-center justify-center p-0 md:p-4 selection:bg-blue-500/50`}>
      {showOnboarding && !isBooting && (
        <Onboarding onFinish={handleFinishOnboarding} setIsSidebarOpenForTutorial={setIsSidebarOpenForTutorial} setHighlightedElementId={setHighlightedElementId} />
      )}
      {currentUser?.privateKey && <ViewKeyModal isOpen={showViewKeyModal} onClose={() => setShowViewKeyModal(false)} privateKey={currentUser.privateKey} />}
      <SettingsModal 
        isOpen={showSettingsModal} 
        onClose={() => setShowSettingsModal(false)} 
        settings={settings} 
        onSettingsChange={handleSettingsChange}
        onResetOnboarding={handleResetOnboarding}
        isTtsEnabled={isTtsEnabled}
        onToggleTts={() => setIsTtsEnabled(prev => !prev)}
      />
      <VerificationModal 
        isOpen={showVerificationModal}
        onClose={() => setShowVerificationModal(false)}
        onSuccess={handleCompleteVerification}
      />
       <SummaryModal
        isOpen={showSummaryModal}
        onClose={() => setShowSummaryModal(false)}
        summary={summaryContent}
        isLoading={isSummarizing}
        theme={theme}
      />
      
      <div className="w-full h-screen max-w-screen-2xl mx-auto flex bg-[#0A0F1A] rounded-2xl overflow-hidden shadow-2xl shadow-blue-500/10 border border-blue-500/20" 
        style={{
          backgroundImage: 'radial-gradient(circle at top left, rgba(59, 130, 246, 0.15), transparent 25%), radial-gradient(circle at bottom right, rgba(59, 130, 246, 0.15), transparent 25%)'
        }}
      >
        <Sidebar 
            isExpanded={isSidebarExpanded}
            hubActions={hubActions}
            selectedHubId={activeView}
            setSelectedHubId={(id) => id ? setActiveView(id as ViewId) : setActiveView('chat')}
            chats={chats}
            activeChatId={activeChatId}
            onNewChat={handleNewChat}
            onSelectChat={handleSelectChat}
            theme={theme}
        />
        <main className="flex-1 flex flex-col min-w-0 bg-[#0A0F1A]/80">
          <Header
            onToggleSidebar={() => setIsSidebarExpanded(!isSidebarExpanded)}
            user={currentUser}
            notifications={notifications}
            onDisconnectWallet={handleDisconnectWallet}
            onAvatarUpload={handleAvatarUpload}
            onOpenSettings={() => setShowSettingsModal(true)}
            onStartVerification={handleStartVerification}
            onViewKey={() => setShowViewKeyModal(true)}
            isSidebarExpanded={isSidebarExpanded}
            onNewChat={handleNewChat}
            onToggleTheme={handleToggleTheme}
            onForkChat={handleForkChat}
            isForking={isForking}
            onSummarizeChat={handleSummarizeChat}
            isSummarizing={isSummarizing}
            onSaveChat={handleSaveChat}
            isSaving={isSaving}
            settings={settings}
            theme={theme}
            activeChat={activeChat || null}
            selectedHub={selectedHub}
            hubActions={hubActions}
            onToggleSystemStatus={handleToggleSystemStatus}
            isSystemStatusVisible={isSystemStatusVisible}
          />
          {renderActiveView()}
        </main>
      </div>
      <FloatingAvatar orbState={orbState} agent={quantumOSAgent} />
    </div>
  );
}

export default App;